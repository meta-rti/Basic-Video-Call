//
//  WujiRtcCryptoCppLoader.h
//  WujiRtcCryptoLoader
//
//  Copyright © 2019 Wuji IO. All rights reserved.
//

#ifndef WujiRtcCryptoCppLoader_h
#define WujiRtcCryptoCppLoader_h

class WujiRtcCryptoCppLoader
{
public:
    WujiRtcCryptoCppLoader();
    ~WujiRtcCryptoCppLoader();
};

#endif /* WujiRtcCryptoCppLoader_h */
