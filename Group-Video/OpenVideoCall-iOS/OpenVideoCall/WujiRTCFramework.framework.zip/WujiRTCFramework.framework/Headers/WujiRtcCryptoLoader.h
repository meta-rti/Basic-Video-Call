//
//  WujiRtcCryptoLoader.h
//  WujiRtcCryptoLoader
//
//  Copyright © 2018 Wuji. All rights reserved.
//

#import <Foundation/Foundation.h>

__attribute__ ((visibility ("default"))) @interface WujiRtcCryptoLoader : NSObject

@end
